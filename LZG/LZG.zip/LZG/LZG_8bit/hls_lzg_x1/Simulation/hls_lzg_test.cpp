#include <stdio.h>
#include <stdlib.h>
#include "hls_lzg.h"


#define Input_Size	61554
#define Output_Size	418496


#define Test_Size 1024

/* LUT for decoding the copy length parameter */
static const unsigned char _LZG_LENGTH_DECODE_LUT[32] = {
    2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,
    18,19,20,21,22,23,24,25,26,27,28,29,35,48,72,128
};


/* Endian and alignment independent reader for 32-bit integers */
#define _LZG_GetUINT32(in, offs) \
    ((((unsigened int)in[offs]) << 24) | \
     (((unsigened int)in[offs+1]) << 16) | \
     (((unsigened int)in[offs+2]) << 8) | \
     ((unsigened int)in[offs+3]))





unsigned int LZG_Decode_sw(unsigned char *in, unsigned char *out, \
		unsigned char m1, unsigned char m2, unsigned char m3, unsigned char m4)
{
    unsigned char *src, *inEnd, *dst, *outEnd, *copy, symbol, b, b2;
    unsigned char marker1, marker2, marker3, marker4, method;
    unsigned int  i, length, offset, encodedSize, decodedSize, checksum;
    char isMarkerSymbolLUT[256];


    /* Initialize the byte streams */
    src = (unsigned char *)in;
    inEnd = ((unsigned char *)in) + Input_Size;
    dst = out;
    outEnd = out + Output_Size;

    /* Get marker symbols from the input stream */
    marker1 = m1;
    marker2 = m2;
    marker3 = m3;
    marker4 = m4;

    /* Initialize marker symbol LUT */
    for (i = 0; i < 256; ++i)
        isMarkerSymbolLUT[i] = 0;
    isMarkerSymbolLUT[marker1] = 1;
    isMarkerSymbolLUT[marker2] = 1;
    isMarkerSymbolLUT[marker3] = 1;
    isMarkerSymbolLUT[marker4] = 1;

    /* Main decompression loop */
    while (src < inEnd)
    {
        /* Get the next symbol */
        symbol = *src++;

        /* Marker symbol? */
        if ((!isMarkerSymbolLUT[symbol]))
        {
            /* Literal copy */
            *dst++ = symbol;
        }
        else
        {
            b = *src++;
            if ((b))
            {
                /* Decode offset / length parameters */
                if ((symbol == marker1))
                {
                    /* Distant copy */
                    length = _LZG_LENGTH_DECODE_LUT[b & 0x1f];
                    b2 = *src++;
                    offset = (((unsigned int)(b & 0xe0)) << 11) |
                              (((unsigned int)b2) << 8) |
                              (*src++);
                    offset += 2056;
                }
                else if ((symbol == marker2))
                {
                    /* Medium copy */
                    length = _LZG_LENGTH_DECODE_LUT[b & 0x1f];
                    b2 = *src++;
                    offset = (((unsigned int)(b & 0xe0)) << 3) | b2;
                    offset += 8;
                }
                else if ((symbol == marker3))
                {
                    /* Short copy */
                    length = (b >> 6) + 3;
                    offset = (b & 0x3f) + 8;
                }
                else
                {
                    /* Near copy (including RLE) */
                    length = _LZG_LENGTH_DECODE_LUT[b & 0x1f];
                    offset = (b >> 5) + 1;
                }

                /* Copy corresponding data from history window */
                copy = dst - offset;

                /* Note: We use loop unrolling to improve the speed */
                switch (length)
                {
                    default:
                        for (i = 29; i < length; ++i)
                            *dst++ = *copy++;
                    case 29: *dst++ = *copy++; case 28: *dst++ = *copy++;
                    case 27: *dst++ = *copy++; case 26: *dst++ = *copy++;
                    case 25: *dst++ = *copy++; case 24: *dst++ = *copy++;
                    case 23: *dst++ = *copy++; case 22: *dst++ = *copy++;
                    case 21: *dst++ = *copy++; case 20: *dst++ = *copy++;
                    case 19: *dst++ = *copy++; case 18: *dst++ = *copy++;
                    case 17: *dst++ = *copy++; case 16: *dst++ = *copy++;
                    case 15: *dst++ = *copy++; case 14: *dst++ = *copy++;
                    case 13: *dst++ = *copy++; case 12: *dst++ = *copy++;
                    case 11: *dst++ = *copy++; case 10: *dst++ = *copy++;
                    case 9:  *dst++ = *copy++; case 8:  *dst++ = *copy++;
                    case 7:  *dst++ = *copy++; case 6:  *dst++ = *copy++;
                    case 5:  *dst++ = *copy++; case 4:  *dst++ = *copy++;
                    case 3:  *dst++ = *copy++; case 2:  *dst++ = *copy++;
                    case 1:  *dst++ = *copy++;
                }
            }
            else
            {
                /* Single occurance of a marker symbol... */
                *dst++ = symbol;
            }
        }
    }

    /* Did we get the right number of output bytes? */
    if ((unsigned int)(dst - out) != Output_Size)
        return 0;

    /* Return size of decompressed buffer */
    return 1;
}












int main(void)
{

	int ret_val = 0;

	int err;

	int out;

	int i;
	int shiftdata;
	
	FILE *fp;

	int source_size = Input_Size;
	int desti_size = Output_Size;

	unsigned char *SourceBuf, *DestBuf_HW, *DestBuf_SW, *gold_buf;
	SourceBuf = (unsigned char*) malloc(source_size);
	DestBuf_HW = (unsigned char*) malloc(desti_size);
	DestBuf_SW = (unsigned char*) malloc(desti_size);
	gold_buf = (unsigned char*) malloc(desti_size);

	int size;
	fp=fopen("input.dat","rb");
	size = fread(SourceBuf, 1, source_size, fp);
	if(size != source_size)
		printf("\n\n\ninput.dat Reading failed!\n\n\n");
	else
		printf("input.dat Reading Successfully!\n");
	fclose(fp);

//	for(i=0;i<16;i++)
//		printf("SourceBuf[%d]: %02x\n", i, SourceBuf[i]);
//	for(i=Input_Size-8;i<Input_Size;i++)
//		printf("SourceBuf[%d]: %02x\n", i, SourceBuf[i]);
//	printf("\n\n\n");

	unsigned char m1, m2, m3, m4;
	m1=0x9D;
	m2=0x17;
	m3=0xE7;
	m4=0x4D;

	printf("\nStart HW decompression...\n");
	for(i=0;i<Test_Size;i++)
		hls_lzg( SourceBuf, DestBuf_HW, m1, m2, m3, m4);


//	for(i=0;i<32;i++)
//		printf("DestBuf_HW[%d]: %02x\n", i, DestBuf_HW[i]);
//	for(i=4096-8;i<4096;i++)
//		printf("DestBuf_HW[%d]: %02x\n", i, DestBuf_HW[i]);
	printf("\nHW decompression done!\n");


	fp=fopen("output.dat","wb");
	size = fwrite(DestBuf_HW, 1, Output_Size, fp);
	if(size != desti_size)
		printf("\n\n\nWriting output.dat failed!\n\n\n");
	else
		printf("Writing output.dat Successfully!\n");
    fclose(fp);


	printf("\nStart SW decompression...\n");
	LZG_Decode_sw( SourceBuf, DestBuf_SW, m1, m2, m3, m4);
	printf("\nSW decompression done!\n");


//	for(i=0;i<16;i++)
//		printf("DestBuf_SW[%d]: %02x\n", i, DestBuf_SW[i]);
//	printf("\n\n\n");



	fp=fopen("gold.dat","rb");
	size = fread(gold_buf, 1, desti_size, fp);
	if(size != desti_size)
		printf("\n\n\nReading gold.dat failed!\n\n\n");
	else
		printf("Reading gold.dat Successfully!\n");
	fclose(fp);


	for(i=0;i<Test_Size;i++)
	{
		if(gold_buf[i] != DestBuf_HW[i])
			break;
	}
	if(i==Test_Size)
		printf("HW decompression success!\n");
	else
		printf("\n\n\n HW decompression failed!\n\n\n");


	
	for(i=0;i<Test_Size;i++)
	{
		if(gold_buf[i] != DestBuf_SW[i])
			break;
	}
	if(i==Test_Size)
		printf("\n SW decompression success!\n");
	else
		printf("\n\n\n SW decompression failed!\n\n\n");	
	
	
	return 0;

}


