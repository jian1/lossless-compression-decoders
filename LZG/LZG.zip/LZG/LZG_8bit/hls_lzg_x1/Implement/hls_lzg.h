void hls_lzg( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout, \
		unsigned char m1, unsigned char m2, unsigned char m3, unsigned char m4);



