void hls_lzg( unsigned char din[2048], unsigned char dout[2048], \
		unsigned char m1, unsigned char m2, unsigned char m3, unsigned char m4);

		
		
		
		
		