void hls_lzg( hls::stream<unsigned short int> &din, hls::stream<unsigned short int> &dout, \
		unsigned char m1, unsigned char m2, unsigned char m3, unsigned char m4);
