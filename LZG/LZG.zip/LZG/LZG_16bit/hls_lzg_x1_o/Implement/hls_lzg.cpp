#include "ap_int.h"
#include "hls_stream.h"
#include <assert.h>
#include <ap_axi_sdata.h>
#include "hls_lzg.h"
#include "ap_shift_reg.h"
#include "ap_int.h"



/* LUT for decoding the copy length parameter */
static const unsigned char _LZG_LENGTH_DECODE_LUT[32] = {
    2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,
    18,19,20,21,22,23,24,25,26,27,28,29,35,48,72,128
};




void hls_lzg( hls::stream<unsigned short int> &din, hls::stream<unsigned short int> &dout, \
		unsigned char m1, unsigned char m2, unsigned char m3, unsigned char m4)
{

#pragma HLS INTERFACE axis port=dout
#pragma HLS INTERFACE axis port=din

    unsigned short int symbol, b;
    unsigned char  i, length;
    ap_uint<11> offset;

    //offset is no more than 2024, that the maximum depth of shift reg is 2048.
    static ap_shift_reg<unsigned short int, 2048> Sreg;

    /* Main decompression loop */


        /* Get the next symbol */
        symbol = din.read();

        /* Marker symbol? */
        if ( ((symbol != (0x00ff & m1)) && (symbol != (0x00ff & m2))) && ((symbol != (0x00ff & m3)) && (symbol !=(0x00ff & m4))) )
        {
            /* Literal copy */
            dout.write(symbol);
            Sreg.shift(symbol,0);
        }
        else
        {
            b = din.read();

            if ( b&0x00FF )
            {
                /* Decode offset / length parameters */
                if (symbol == m2)
                {
                    /* Medium copy */
                    length = _LZG_LENGTH_DECODE_LUT[b & 0x001f];
//                    b2 = din.read();
//                    offset = (((unsigned short int)(b & 0xe0)) << 3) | b2;
                    offset = (((unsigned short int)(b & 0x00e0)) << 3) | ((0xff00 & b)>>8);
                    offset += 8;
                }
                else if (symbol == m3)
                {
                    /* Short copy */
                    length = ((b&0x00FF) >> 6) + 3;
                    offset = (b & 0x003f) + 8;
                }
                else
                {
                    /* Near copy (including RLE) */
                    length = _LZG_LENGTH_DECODE_LUT[b & 0x001f];
                    offset = ((b&0x00FF) >> 5) + 1;
                }

                /* Copy corresponding data from history window */
                /* Note: We use loop unrolling to improve the speed */
                //the length is no more than 128.
//                unsigned short int tmp;
                unsigned short int tmp,tmp1;

//                L1:for (i=0; i<256; i++) {
//                	if(i<length) {
//                    	tmp = Sreg.read(offset-1);
//                      dout.write(tmp);
//                      Sreg.shift(tmp,0);
//                	}
//                }

//                tmp = Sreg.read(offset-1);
//                L1:for (i=0; i<length; i++) {
//                	dout.write(tmp);
//                	tmp = Sreg.shift(tmp,offset-1);
//
//                }


                tmp = Sreg.read(offset-1);
                if( offset>1) {
                	L1:for (i=0; i<length; i++) {
                		dout.write(tmp);
                		tmp1 = Sreg.shift(tmp,offset-2);
                		tmp=tmp1;
                	}
                }
                else {
                	L2:for (i=0; i<length; i++) {
                		dout.write(tmp);
                		Sreg.shift(tmp,0);
                	}
                }




            }
            else
            {
                /* Single occurance of a marker symbol... */
                dout.write(symbol);
                Sreg.shift(symbol,0);
            }
        }



}










