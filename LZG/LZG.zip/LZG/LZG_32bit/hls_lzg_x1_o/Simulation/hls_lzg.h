void hls_lzg( unsigned int din[2048], unsigned int dout[20480], \
		unsigned char m1, unsigned char m2, unsigned char m3, unsigned char m4);
