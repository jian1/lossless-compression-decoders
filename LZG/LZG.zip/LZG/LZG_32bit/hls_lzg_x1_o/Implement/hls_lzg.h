void hls_lzg( hls::stream<unsigned int> &din, hls::stream<unsigned int> &dout, \
		unsigned char m1, unsigned char m2, unsigned char m3, unsigned char m4);


