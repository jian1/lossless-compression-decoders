#include "ap_int.h"
#include "hls_stream.h"
#include <assert.h>
#include <ap_axi_sdata.h>
#include "hls_rle.h"



void hls_rle( hls::stream<int> &din, hls::stream<int> &dout)
{

#pragma HLS INTERFACE axis port=dout
#pragma HLS INTERFACE axis port=din

	int iSymbol,iActual;
	int iRep;
	int iCont;

	iSymbol = din.read();
	if (iSymbol == 0x17171717) {
		iRep = din.read();
		iActual = din.read();
		L1:for (iCont = 0; iCont <= iRep; iCont++) {
			dout.write(iActual);
		}
	}
	else {
		dout.write(iSymbol);
	}

	
	
	
	iSymbol = din.read();
	if (iSymbol == 0x17171717) {
		iRep = din.read();
		iActual = din.read();
		L2:for (iCont = 0; iCont <= iRep; iCont++) {
			dout.write(iActual);
		}
	}
	else {
		dout.write(iSymbol);
	}	
	
	

	iSymbol = din.read();
	if (iSymbol == 0x17171717) {
		iRep = din.read();
		iActual = din.read();
		L3:for (iCont = 0; iCont <= iRep; iCont++) {
			dout.write(iActual);
		}
	}
	else {
		dout.write(iSymbol);
	}	


	
	
	
}

