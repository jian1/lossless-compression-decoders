#include <stdio.h>
#include <stdlib.h>
#include "hls_rle.h"


#define Input_Size	34635
#define Output_Size	418496


#define Test_Size 128



void hls_rle_sw( int din[4096], int dout[81920] )
// void hls_rle( hls::stream<int> &din, hls::stream<int> &dout)
{

	int iSymbol,iActual;
	int iRep;
	int iCont;
	
	static int j=0, k=0;

//	iSymbol = din.read();
	iSymbol = din[j++];
	if (iSymbol == 0x17171717) {
//		iRep = din.read();
		iRep = din[j++];
//		iActual = din.read();
		iActual = din[j++];
		L1:for (iCont = 0; iCont <= iRep; iCont++) {
//			dout.write(iActual);
			dout[k++]=iActual;
		}
	}
	else {
//		dout.write(iSymbol);
		dout[k++]=iSymbol;
	}

}












int main(void)
{

	int ret_val = 0;

	int err;

	int out;

	int i;
	int shiftdata;
	
	FILE *fp;

	int source_size = Input_Size;
	int desti_size = Output_Size;

	int *SourceBuf, *DestBuf_HW, *DestBuf_SW, *gold_buf;
	SourceBuf = (int*) malloc(source_size);
	DestBuf_HW = (int*) malloc(desti_size);
	DestBuf_SW = (int*) malloc(desti_size);
	gold_buf = (int*) malloc(desti_size);

	int size;
	fp=fopen("input.dat","rb");
	size = fread(SourceBuf, 1, source_size, fp);
	if(size != source_size)
		printf("\n\n\ninput.dat Reading failed!\n\n\n");
	else
		printf("input.dat Reading Successfully!\n");
	fclose(fp);

//	for(i=0;i<16;i++)
//		printf("SourceBuf[%d]: %02x\n", i, SourceBuf[i]);
//	for(i=Input_Size-8;i<Input_Size;i++)
//		printf("SourceBuf[%d]: %02x\n", i, SourceBuf[i]);
	printf("\n\n\n");


	printf("\nStart HW decompression...\n");
	for(i=0;i<Test_Size;i++)
		hls_rle( SourceBuf, DestBuf_HW);


//	for(i=0;i<32;i++)
//		printf("DestBuf_HW[%d]: %02x\n", i, DestBuf_HW[i]);
//	for(i=4096-8;i<4096;i++)
//		printf("DestBuf_HW[%d]: %02x\n", i, DestBuf_HW[i]);
	printf("\nHW decompression done!\n");


	fp=fopen("output.dat","wb");
	size = fwrite(DestBuf_HW, 1, Output_Size, fp);
	if(size != desti_size)
		printf("\n\n\nWriting output.dat failed!\n\n\n");
	else
		printf("Writing output.dat Successfully!\n");
    fclose(fp);


	printf("\nStart SW decompression...\n");
	for(i=0;i<Test_Size;i++)
		hls_rle_sw( SourceBuf, DestBuf_SW);
	printf("\nSW decompression done!\n");


//	for(i=0;i<16;i++)
//		printf("DestBuf_SW[%d]: %02x\n", i, DestBuf_SW[i]);
	printf("\n\n\n");



	fp=fopen("gold.dat","rb");
	size = fread(gold_buf, 1, desti_size, fp);
	if(size != desti_size)
		printf("\n\n\nReading gold.dat failed!\n\n\n");
	else
		printf("Reading gold.dat Successfully!\n");
	fclose(fp);


	for(i=0;i<Test_Size;i++)
	{
		if(gold_buf[i] != DestBuf_HW[i])
			break;
	}
	if(i==Test_Size)
		printf("HW decompression success!\n");
	else
		printf("\n\n\n HW decompression failed!\n\n\n");


	
	for(i=0;i<Test_Size;i++)
	{
		if(gold_buf[i] != DestBuf_SW[i])
			break;
	}
	if(i==Test_Size)
		printf("\n SW decompression success!\n");
	else
		printf("\n\n\n SW decompression failed!\n\n\n");	
	
	
	return 0;

}


