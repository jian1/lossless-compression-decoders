void hls_rle( int din[4096], int dout[81920] );
