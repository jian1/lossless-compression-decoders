void hls_rle( hls::stream<int> &din, hls::stream<int> &dout);


