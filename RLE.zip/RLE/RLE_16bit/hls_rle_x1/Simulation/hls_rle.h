void hls_rle( unsigned short int din[4096], unsigned short int dout[81920] );
