#include "ap_int.h"
#include "hls_stream.h"
#include <assert.h>
#include <ap_axi_sdata.h>
#include "hls_rle.h"


void hls_rle( unsigned short int din[4096], unsigned short int dout[81920] )
// void hls_rle( hls::stream<unsigned short int> &din, hls::stream<unsigned short int> &dout)
{

// #pragma HLS INTERFACE axis port=dout
// #pragma HLS INTERFACE axis port=din

	unsigned short int iSymbol,iActual;
	unsigned short int iRep;
	unsigned short int iCont;
	
	static int j=0, k=0;
	
	

//	iSymbol = din.read();
	iSymbol = din[j++];
	if (iSymbol == 0x1717) {
//		iRep = din.read();
		iRep = din[j++];
//		iActual = din.read();
		iActual = din[j++];
		L1:for (iCont = 0; iCont <= iRep; iCont++) {
//			dout.write(iActual);
			dout[k++]=iActual;
		}
	}
	else {
//		dout.write(iSymbol);
		dout[k++]=iSymbol;
	}

}

