void hls_rle( hls::stream<unsigned short int> &din, hls::stream<unsigned short int> &dout);


