void hls_rle( unsigned char din[4096], unsigned char dout[81920] );
