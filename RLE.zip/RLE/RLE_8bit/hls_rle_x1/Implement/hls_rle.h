void hls_rle( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout);


