#include "ap_int.h"
#include "hls_stream.h"
#include <assert.h>
#include <ap_axi_sdata.h>
#include "hls_rle.h"



void hls_rle( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout)
{

#pragma HLS INTERFACE axis port=dout
#pragma HLS INTERFACE axis port=din

	unsigned char iSymbol,iActual;
	unsigned char iRep;
	unsigned char iCont;

	iSymbol = din.read();
	if (iSymbol == 0x17) {
		iRep = din.read();
		iActual = din.read();
		L1:for (iCont = 0; iCont <= iRep; iCont++) {
			dout.write(iActual);
		}
	}
	else {
		dout.write(iSymbol);
	}

}

