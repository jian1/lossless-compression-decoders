#include "ap_int.h"
void hls_lz77_decode( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout, ap_uint<12> block_size, unsigned int dst_len);

