#include "ap_int.h"
#include "hls_stream.h"
#include <assert.h>
#include <ap_axi_sdata.h>
#include "hls_lz77_decode.h"
#include "ap_shift_reg.h"
#include "ap_int.h"



void hls_lz77_decode( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout, ap_uint<12> block_size, unsigned int dst_len)
{

#pragma HLS INTERFACE axis port=dout
#pragma HLS INTERFACE axis port=din

//offset is no more than 2048, that the maximum depth of shift reg is 2048.
static ap_shift_reg<unsigned char, 2048> Sreg;

	ap_uint<16> i,len;
	static ap_uint<4> block=0;
	static ap_uint<5> shift=16;
	static ap_uint<12> border=1;

	ap_uint<12> p;
	static unsigned char flag=0;
	ap_uint<16> ptmp;

	unsigned char tmp1,tmp2;

	static unsigned int target=0;
	static ap_uint<12> t=0;

	if(t==0 || t==block_size || target==0)
	{
		t=0;
		flag = din.read();
		block = 0;				// block - bit in single flag byte
		shift = 16;				// shift offset to most significant bits
		border = 1;				// offset can`t be more then border
	}

	if (shift > 4)
		w1: while ( t >= border )
		{
			if (shift <= 4) break;
			border = border << 1;
			shift = shift-1;
		}

	if ( flag & (1<<block) )
	{
		tmp1 = din.read();
		tmp2 = din.read();
		ptmp = (tmp2<<8) | tmp1;
		len = ((1<<shift)-1) & ptmp;
		p = ptmp>>shift;

		tmp1 = Sreg.read(p);
		if( p>0) {
			for (i=0; i<len; i++) {
				dout.write(tmp1);
				tmp2 = Sreg.shift(tmp1,p-1);
				tmp1=tmp2;
			}
		}
		else
		{
			for (i=0; i<len; i++) {
				dout.write(tmp1);
				Sreg.shift(tmp1,0);
			}
		}
		t = t + len;
		target = target + len;
		if(target==dst_len)
			target=0;
	}
	else
	{
		tmp1 = din.read();
		dout.write(tmp1);
		Sreg.shift(tmp1,0);
		t++;
		target++;
		if(target==dst_len)
			target=0;
	}

	if (++block >= 8)
	{
		flag = din.read();
		block = 0;
	}


}







