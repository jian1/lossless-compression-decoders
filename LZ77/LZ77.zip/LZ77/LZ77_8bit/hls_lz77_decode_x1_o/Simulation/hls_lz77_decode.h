#include "ap_int.h"


void hls_lz77_decode( unsigned char din[4096], unsigned char dout[81920], ap_uint<12> block_size);

