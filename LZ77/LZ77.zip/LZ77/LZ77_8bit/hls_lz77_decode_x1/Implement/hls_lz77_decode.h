void hls_lz77_decode( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout, unsigned int block_size, unsigned int dst_len);

