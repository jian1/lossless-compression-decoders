void hls_lz77_decode( unsigned char din[4096], unsigned char dout[81920], unsigned int block_size);

