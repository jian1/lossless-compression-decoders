#include <stdio.h>
#include <stdlib.h>
#include "hls_lz77_decode.h"
#include "ap_shift_reg.h"


#define Input_Size	4096
#define Output_Size	119094
#define block_size_N 2048

#define Test_Size 128



/* Endian and alignment independent reader for 32-bit integers */
#define _GetUINT32(in, offs) \
    ((((unsigened int)in[offs]) << 24) | \
     (((unsigened int)in[offs+1]) << 16) | \
     (((unsigened int)in[offs+2]) << 8) | \
     ((unsigened int)in[offs+3]))






//void hls_lz77_decode( hls::stream<unsigned int> &din, hls::stream<unsigned int> &dout, unsigned int block_size)
void hls_lz77_decode_sw( unsigned char din[4096], unsigned char dout[81920], unsigned int block_size)
{

//#pragma HLS INTERFACE axis port=dout
//#pragma HLS INTERFACE axis port=din

//offset is no more than 2048, that the maximum depth of shift reg is 2048.
static ap_shift_reg<unsigned char, 2048> Sreg;

	unsigned int i;
	unsigned int len;
	static unsigned int block=0, shift=16, border=1;
	int p;
	static unsigned char flag=0;
	unsigned int ptmp;

	unsigned char tmp1,tmp2;

	static unsigned int t=0;

	static int j=0, k=0;

	if(t==0 || t==block_size)
	{
		t=0;
//		flag = din.read();
		flag = din[j++];
		block = 0;				// block - bit in single flag byte
		shift = 16;				// shift offset to most significant bits
		border = 1;				// offset can`t be more then border
	}

	if (shift > 4)
		w1: while ( t >= border )
		{
			if (shift <= 4) break;
			border = border << 1;
			shift = shift-1;
		}

	if ( flag & (1<<block) )
	{
//		tmp1 = din.read();
//		tmp2 = din.read();
		tmp1 = din[j++];
		tmp2 = din[j++];
		ptmp = (tmp2<<8) | tmp1;
		len = ((1<<shift)-1) & ptmp;
		p = ptmp>>shift;

		tmp1 = Sreg.read(p);
		if( p>0) {
			for (i=0; i<len; i++) {
//				dout.write(tmp1);
//				printf("tmp1[%d]: %02x. din[%d]: %02x\n", k, tmp1, j, din[j]);
				dout[k++] = tmp1;
				tmp2 = Sreg.shift(tmp1,p-1);
				tmp1=tmp2;
			}
		}
		else
		{
			for (i=0; i<len; i++) {
//				dout.write(tmp1);
				dout[k++] = tmp1;
//				printf("tmp1: %02x\n", tmp1);
				Sreg.shift(tmp1,0);
			}
		}
		t = t + len;
	}
	else
	{
//		tmp1 = din.read();
		tmp1 = din[j++];
//		dout.write(tmp1);
//		printf("tmp1[%d]: %02x. din[%d]: %02x\n", k, tmp1, j, din[j]);
		dout[k++] = tmp1;
		Sreg.shift(tmp1,0);
		t++;
	}

	if (++block >= 8)
	{
//		flag = din.read();
		flag = din[j++];
		block = 0;
	}


}






int main(void)
{

	int ret_val = 0;

	int err;

	int out;

	int i;
	int shiftdata;
	
	FILE *fp;

	int source_size = Input_Size;
	int desti_size = Output_Size;

	unsigned char *SourceBuf, *DestBuf_HW, *DestBuf_SW, *gold_buf;
	SourceBuf = (unsigned char*) malloc(source_size);
	DestBuf_HW = (unsigned char*) malloc(desti_size);
	DestBuf_SW = (unsigned char*) malloc(desti_size);
	gold_buf = (unsigned char*) malloc(desti_size);

	int size;
	fp=fopen("input.dat","rb");
	size = fread(SourceBuf, 1, source_size, fp);
	if(size != source_size)
		printf("\n\n\ninput.dat Reading failed!\n\n\n");
	else
		printf("input.dat Reading Successfully!\n");
	fclose(fp);

//	for(i=0;i<16;i++)
//		printf("SourceBuf[%d]: %02x\n", i, SourceBuf[i]);
//	for(i=Input_Size-8;i<Input_Size;i++)
//		printf("SourceBuf[%d]: %02x\n", i, SourceBuf[i]);
//	printf("\n\n\n");


	printf("\nStart HW decompression...\n");
	for(i=0;i<Test_Size;i++)
		hls_lz77_decode( SourceBuf, DestBuf_HW, block_size_N);


//	for(i=0;i<32;i++)
//		printf("DestBuf_HW[%d]: %02x\n", i, DestBuf_HW[i]);
//	for(i=4096-8;i<4096;i++)
//		printf("DestBuf_HW[%d]: %02x\n", i, DestBuf_HW[i]);
	printf("\nHW decompression done!\n");


	fp=fopen("output.dat","wb");
	size = fwrite(DestBuf_HW, 1, Output_Size, fp);
	if(size != desti_size)
		printf("\n\n\nWriting output.dat failed!\n\n\n");
	else
		printf("Writing output.dat Successfully!\n");
    fclose(fp);


	printf("\nStart SW decompression...\n");
	for(i=0;i<Test_Size;i++)
		hls_lz77_decode_sw( SourceBuf, DestBuf_SW, block_size_N);
	printf("\nSW decompression done!\n");


//	for(i=0;i<16;i++)
//		printf("DestBuf_SW[%d]: %02x\n", i, DestBuf_SW[i]);
//	printf("\n\n\n");



	fp=fopen("gold.dat","rb");
	size = fread(gold_buf, 1, desti_size, fp);
	if(size != desti_size)
		printf("\n\n\nReading gold.dat failed!\n\n\n");
	else
		printf("Reading gold.dat Successfully!\n");
	fclose(fp);


	for(i=0;i<Test_Size;i++)
	{
		if(gold_buf[i] != DestBuf_HW[i])
			break;
	}
	if(i==Test_Size)
		printf("HW decompression success!\n");
	else
		printf("\n\n\n HW decompression failed!\n\n\n");


	
	for(i=0;i<Test_Size;i++)
	{
		if(gold_buf[i] != DestBuf_SW[i])
			break;
	}
	if(i==Test_Size)
		printf("\n SW decompression success!\n");
	else
		printf("\n\n\n SW decompression failed!\n\n\n");	
	
	
	return 0;

}


