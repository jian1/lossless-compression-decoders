#include "ap_int.h"
#include "hls_stream.h"
#include <assert.h>
#include <ap_axi_sdata.h>
#include "hls_lzss_decode.h"
#include "ap_shift_reg.h"




//void hls_lzss_decode( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout, unsigned int dst_len)
void hls_lzss_decode( unsigned char din[4096], unsigned char dout[81920], unsigned int dst_len)
{

#pragma HLS INTERFACE axis port=dout
#pragma HLS INTERFACE axis port=din

////offset is no more than 4114, that the maximum depth of shift reg is 4114.
//static ap_shift_reg<unsigned char, 4114> Sreg;
	static unsigned char buf[4114];

	static unsigned int r=4078, flags=0;
	unsigned char c;
	static int i=0,j=0, k=0;
	static int d,o;
	static unsigned int target=0;

	if(target==0)
	{
		r=4078;
		flags=0;
	}

	if( ((flags>>=1)&256) == 0 )
	{
		c = din[d++];
//		c = din.read();
		flags = c | 0xff00;
	}

	if( flags & 1 )
	{
		c = din[d++];
//		c = din.read();
		dout[o++] = c;
//		dout.write(c);
		buf[r++] = c;
		r &= 4095;
		
		target++;
		if(target==dst_len)
			target=0;		

	}
	else
	{
		i = din[d++];
//		i = din.read();
		j = din[d++];
//		j = din.read();
		i |= ((j & 0xf0) << 4);
		j = (j & 0x0f) + 2;

		for(k=0;k<=j;k++)
		{
			c= buf[(i+k)&4095];
			dout[o++] = c;
//			dout.write(c);
			buf[r++] = c;
			r &= 4095;
		}
		
		target = target +j+1;
		if(target==dst_len)
			target=0;		
		

	}

}




