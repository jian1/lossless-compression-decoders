void hls_lzss_decode( unsigned char din[4096], unsigned char dout[81920], unsigned int dst_len);


