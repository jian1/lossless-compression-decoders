#include <stdio.h>
#include <stdlib.h>
#include "hls_lzss_decode.h"
#include "ap_shift_reg.h"


#define Input_Size	28079
#define Output_Size	118996

#define Test_Size 128





//void hls_lzss_decode( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout, unsigned int dst_len)
void hls_lzss_decode_sw( unsigned char din[4096], unsigned char dout[81920])
{

#pragma HLS INTERFACE axis port=dout
#pragma HLS INTERFACE axis port=din

////offset is no more than 4114, that the maximum depth of shift reg is 4114.
//static ap_shift_reg<unsigned char, 4114> Sreg;
	static unsigned char buf[4114];

	static unsigned int r=4078, flags=0;
	unsigned char c;
	static int i=0,j=0, k=0;
	static int d,o;


	if( ((flags>>=1)&256) == 0 )
	{
		c = din[d++];
//		c = din.read();
		flags = c | 0xff00;
	}

	if( flags & 1 )
	{
		c = din[d++];
//		c = din.read();
		dout[o++] = c;
//		dout.write(c);
		buf[r++] = c;
		r &= 4095;

	}
	else
	{
		i = din[d++];
//		i = din.read();
		j = din[d++];
//		j = din.read();
		i |= ((j & 0xf0) << 4);
		j = (j & 0x0f) + 2;

		for(k=0;k<=j;k++)
		{
			c= buf[(i+k)&4095];
			dout[o++] = c;
//			dout.write(c);
			buf[r++] = c;
			r &= 4095;
		}

	}

}








int main(void)
{

	int ret_val = 0;

	int err;

	int out;

	int i;
	int shiftdata;
	
	FILE *fp;

	int source_size = Input_Size;
	int desti_size = Output_Size;

	unsigned char *SourceBuf, *DestBuf_HW, *DestBuf_SW, *gold_buf;
	SourceBuf = (unsigned char*) malloc(source_size);
	DestBuf_HW = (unsigned char*) malloc(desti_size);
	DestBuf_SW = (unsigned char*) malloc(desti_size);
	gold_buf = (unsigned char*) malloc(desti_size);

	int size;
	fp=fopen("input.dat","rb");
	size = fread(SourceBuf, 1, source_size, fp);
	if(size != source_size)
		printf("\n\n\ninput.dat Reading failed!\n\n\n");
	else
		printf("input.dat Reading Successfully!\n");
	fclose(fp);

//	for(i=0;i<16;i++)
//		printf("SourceBuf[%d]: %02x\n", i, SourceBuf[i]);
//	for(i=Input_Size-8;i<Input_Size;i++)
//		printf("SourceBuf[%d]: %02x\n", i, SourceBuf[i]);
//	printf("\n\n\n");


	printf("\nStart HW decompression...\n");
	for(i=0;i<Test_Size;i++)
		hls_lzss_decode( SourceBuf, DestBuf_HW, Output_Size);


//	for(i=0;i<32;i++)
//		printf("DestBuf_HW[%d]: %02x\n", i, DestBuf_HW[i]);
//	for(i=4096-8;i<4096;i++)
//		printf("DestBuf_HW[%d]: %02x\n", i, DestBuf_HW[i]);
	printf("\nHW decompression done!\n");


	fp=fopen("output.dat","wb");
	size = fwrite(DestBuf_HW, 1, Output_Size, fp);
	if(size != desti_size)
		printf("\n\n\nWriting output.dat failed!\n\n\n");
	else
		printf("Writing output.dat Successfully!\n");
    fclose(fp);


	printf("\nStart SW decompression...\n");
	for(i=0;i<Test_Size;i++)
		hls_lzss_decode_sw( SourceBuf, DestBuf_SW);
	printf("\nSW decompression done!\n");


//	for(i=0;i<16;i++)
//		printf("DestBuf_SW[%d]: %02x\n", i, DestBuf_SW[i]);
//	printf("\n\n\n");



	fp=fopen("gold.dat","rb");
	size = fread(gold_buf, 1, desti_size, fp);
	if(size != desti_size)
		printf("\n\n\nReading gold.dat failed!\n\n\n");
	else
		printf("Reading gold.dat Successfully!\n");
	fclose(fp);


	for(i=0;i<Test_Size;i++)
	{
		if(gold_buf[i] != DestBuf_HW[i])
			break;
	}
	if(i==Test_Size)
		printf("HW decompression success!\n");
	else
		printf("\n\n\n HW decompression failed!\n\n\n");


	
	for(i=0;i<Test_Size;i++)
	{
		if(gold_buf[i] != DestBuf_SW[i])
			break;
	}
	if(i==Test_Size)
		printf("\n SW decompression success!\n");
	else
		printf("\n\n\n SW decompression failed!\n\n\n");	
	
	
	return 0;

}


