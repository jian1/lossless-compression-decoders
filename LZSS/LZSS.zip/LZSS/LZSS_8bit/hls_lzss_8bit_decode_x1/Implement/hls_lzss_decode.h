void hls_lzss_decode( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout, unsigned int dst_len);


