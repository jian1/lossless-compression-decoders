#include "ap_int.h"
#include "hls_stream.h"
#include <assert.h>
#include <ap_axi_sdata.h>
#include "hls_lzss_decode.h"
#include "ap_shift_reg.h"




void hls_lzss_decode( hls::stream<unsigned char> &din, hls::stream<unsigned char> &dout, unsigned int dst_len)
//void hls_lzss_decode( unsigned char din[4096], unsigned char dout[81920])
{

#pragma HLS INTERFACE axis port=dout
#pragma HLS INTERFACE axis port=din

//that the maximum depth of buf is 4097.
//The maximum r is 4096
	static unsigned char buf[4097];
//The maximum r is 4096
	static ap_uint<13>	r=4078;
	static ap_uint<16>	flags=0;

	unsigned char c;

	static ap_uint<12>	i=0;
	static ap_uint<8>	j=0;
	static ap_uint<5>	k=0;

	static unsigned int target=0;

	if(target==0)
	{
		r=4078;
		flags=0;
	}

	if( ((flags>>=1)&256) == 0 )
	{
//		c = din[d++];
		c = din.read();
		flags = c | 0xff00;
	}

	if( flags & 1 )
	{
//		c = din[d++];
		c = din.read();
//		dout[o++] = c;
		dout.write(c);
		buf[r++] = c;
		r &= 4095;

		target++;
		if(target==dst_len)
			target=0;

	}
	else
	{
//		i = din[d++];
		i = din.read();
//		j = din[d++];
		j = din.read();
		i |= ((j & 0xf0) << 4);
		j = (j & 0x0f) + 2;

		for(k=0;k<=j;k++)
		{
			c= buf[(i+k)&4095];
//			dout[o++] = c;
			dout.write(c);
			buf[r++] = c;
			r &= 4095;
		}

		target = target +j+1;
		if(target==dst_len)
			target=0;

	}

}




